$RootPath = $PSScriptRoot

. "$RootPath\setupEnv.ps1" ; . "$RootPath\execDaemon.ps1"