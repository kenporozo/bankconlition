$RootPath = $PSScriptRoot

. "$RootPath\setupEnv.ps1" -and . "$RootPath\execDaemon.ps1"